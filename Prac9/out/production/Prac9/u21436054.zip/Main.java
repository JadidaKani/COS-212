public class Main
{
    public static void main(String[] args) throws Exception
    {
        //AdjacencyList
        AdjacencyList<Character> list = new AdjacencyList<>();

        //addNode
        list.addNode('A');
        list.addNode('B');
        list.addNode('B');
        list.addNode('C');
        list.addNode('D');
        //System.out.println(list.display());

        //addEdge
        list.addEdge('A','B');
        //System.out.println(list.display());
        list.addEdge('A','C');
        //System.out.println(list.display());
        list.addEdge('B','C');
        //System.out.println(list.display());
        list.addEdge('A','Z');
        //System.out.println(list.display());

        //containsNode
        list.containsNode('A');
        list.containsNode('Z');

        //indexOfNode
        list.indexOfNode('A');
        list.indexOfNode('B');
        list.indexOfNode('Z');

        //isConnected
        list.isConnected('A','Z');
        list.isConnected('A','B');

        //removeNode
        list.removeNode('D');
        //System.out.println(list.display());
        list.removeNode('C');
        //System.out.println(list.display());
        list.addNode('C');
        list.addNode('D');
        list.addEdge('A','C');
        list.addEdge('B','C');
        //System.out.println(list.display());

        //removeEdge
        list.removeEdge('A','C');
        list.removeEdge('A','D');
        list.removeEdge('A','Z');
        list.removeEdge('A','B');

        list.addEdge('A','C');
        list.addEdge('A','D');
        list.addEdge('A','B');
        //System.out.println(list.display());

        //numberOfNodes
        list.numberOfNodes();

        //numberOfEdges
        list.numberOfEdges();

        //nodeAtIndex
        list.nodeAtIndex(4);
        list.nodeAtIndex(3);

        //getNeighbors
        list.getNeighbors('A');

        //AdjacencyMatrix
        AdjacencyMatrix<Character> matrix = new AdjacencyMatrix();

        //addNode
        matrix.addNode('A');
        //System.out.println(matrix.display());
        matrix.addNode('B');
        //System.out.println(matrix.display());
        matrix.addNode('C');
        //System.out.println(matrix.display());
        matrix.addNode('D');
        //System.out.println(matrix.display());

        //addEdge
        matrix.addEdge('A','C');
        //System.out.println(matrix.display());
        matrix.addEdge('A','D');
        //System.out.println(matrix.display());
        matrix.addEdge('A','B');
        //System.out.println(matrix.display());
        matrix.addEdge('A','Z');
        //System.out.println(matrix.display());

        //contiansNode
        matrix.containsNode('A');
        matrix.containsNode('B');
        matrix.containsNode('Z');

        //isConnected
        matrix.isConnected('A','Z');
        matrix.isConnected('A','C');

        //removeNode
        matrix.removeNode('D');
        //System.out.println(matrix.display());
        matrix.addNode('D');
        matrix.addEdge('A','D');
        //System.out.println(matrix.display());

        //removeEdge
        matrix.removeEdge('A','C');
        //System.out.println(matrix.display());
        matrix.removeEdge('A','D');
        //System.out.println(matrix.display());
        matrix.removeEdge('A','Z');
        //System.out.println(matrix.display());
        matrix.removeEdge('A','B');
        //System.out.println(matrix.display());

        matrix.addEdge('A','B');
        matrix.addEdge('A','C');
        matrix.addEdge('A','D');
        //System.out.println(matrix.display());

        //number of nodes
        matrix.numberOfNodes();

        //numberOfEdges
        matrix.numberOfEdges();

        //indexOfNode
        matrix.indexOfNode('D');
        matrix.indexOfNode('Z');

        //nodeAtIndex
        matrix.nodeAtIndex(0);
        matrix.nodeAtIndex(4);

        //getNeighbors
        matrix.getNeighbors('A');

        //UndiredctedGraph with adjacencyList
        GraphImplementation graphImpl1 = new AdjacencyList<>();
        UndirectedGraph undirectedGraph1 = new UndirectedGraph<>(graphImpl1);

        undirectedGraph1.addNode('A');
        undirectedGraph1.addNode('B');
        undirectedGraph1.addNode('C');
        undirectedGraph1.addNode('D');
        undirectedGraph1.display();

        undirectedGraph1.addEdge('A','B');
        undirectedGraph1.display();

        undirectedGraph1.removeEdge('A','B');
        undirectedGraph1.display();

        undirectedGraph1.addEdge('A','B');
        undirectedGraph1.addEdge('A','C');
        undirectedGraph1.addEdge('B','D');
        undirectedGraph1.display();
        LinkedList undrBfs1 = undirectedGraph1.bfs('A');
        undrBfs1.printList();

        LinkedList undrDfs1 = undirectedGraph1.dfs('A');
        undrDfs1.printList();

        LinkedList short1 = undirectedGraph1.unweightedShortestPath('A','D');
        short1.printList();

        //Undirected Garph with Adjacency Matrix
        GraphImplementation graphImpl2 = new AdjacencyMatrix<>();
        UndirectedGraph undirectedGraph2 = new UndirectedGraph<>(graphImpl2);

        undirectedGraph2.addNode('A');
        undirectedGraph2.addNode('B');
        undirectedGraph2.addNode('C');
        undirectedGraph2.addNode('D');
        undirectedGraph2.display();

        undirectedGraph2.addEdge('A','B');
        undirectedGraph2.display();

        undirectedGraph2.removeEdge('A','B');
        undirectedGraph2.display();

        undirectedGraph2.addEdge('A','B');
        undirectedGraph2.addEdge('A','C');
        undirectedGraph2.addEdge('B','D');
        undirectedGraph2.display();
        LinkedList undrBfs2 = undirectedGraph2.bfs('A');
        undrBfs2.printList();

        LinkedList undrDfs2 = undirectedGraph2.dfs('A');
        undrDfs2.printList();

        LinkedList short2 = undirectedGraph2.unweightedShortestPath('A','D');
        short2.printList();

        //DirectedGraph with adjacencyList
        GraphImplementation graphImpl3 = new AdjacencyList<>();
        DirectedGraph directedGraph1 = new DirectedGraph<>(graphImpl3);

        directedGraph1.addNode('A');
        directedGraph1.addNode('B');
        directedGraph1.addNode('C');
        directedGraph1.addNode('D');
        directedGraph1.display();

        directedGraph1.addEdge('A','B');
        directedGraph1.display();

        directedGraph1.removeEdge('A','B');
        directedGraph1.display();

        directedGraph1.addEdge('A','B');
        directedGraph1.addEdge('A','C');
        directedGraph1.addEdge('B','D');
        directedGraph1.display();
        LinkedList drBfs1 = directedGraph1.bfs('A');
        drBfs1.printList();

        LinkedList drDfs1 = directedGraph1.dfs('A');
        drDfs1.printList();

        LinkedList short3 = directedGraph1.unweightedShortestPath('A','D');
        short3.printList();

        //Directed Graph with Adjacency Matrix
        GraphImplementation graphImpl4 = new AdjacencyMatrix<>();
        DirectedGraph directedGraph2 = new DirectedGraph<>(graphImpl4);

        directedGraph2.addNode('A');
        directedGraph2.addNode('B');
        directedGraph2.addNode('C');
        directedGraph2.addNode('D');
        directedGraph2.display();

        directedGraph2.addEdge('A','B');
        directedGraph2.display();

        directedGraph2.removeEdge('A','B');
        directedGraph2.display();

        directedGraph2.addEdge('A','B');
        directedGraph2.addEdge('A','C');
        directedGraph2.addEdge('B','D');
        directedGraph2.display();
        LinkedList drBfs2 = directedGraph2.bfs('A');
        drBfs2.printList();

        LinkedList drDfs2 = directedGraph2.dfs('A');
        drDfs2.printList();

        LinkedList short4 = directedGraph2.unweightedShortestPath('A','D');
        short4.printList();


    }
}
